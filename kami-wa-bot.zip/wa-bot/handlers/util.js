function jidToNumber(jid = "") {
  return jid.split("@")[0].split(":")[0];
}

function isAdmin(number, config) {
  const all = new Set([config.ownerNumber, ...config.adminNumbers]);
  return all.has(number);
}

module.exports = { jidToNumber, isAdmin };
