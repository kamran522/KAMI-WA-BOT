/**
 * Auto status viewer — automatically marks contacts' status updates as "viewed"
 * (the normal WhatsApp read-receipt for statuses that are shared with you).
 * This does not touch anyone's private messages, only statuses that were
 * already shared with the linked account.
 */

const config = require("../config");

function startAutoStatusView(sock) {
  sock.ev.on("messages.upsert", async ({ messages, type }) => {
    if (type !== "notify") return;
    if (!config.features.autoStatusView) return;

    for (const msg of messages) {
      try {
        if (msg.key.remoteJid === "status@broadcast" && msg.key.participant) {
          await sock.readMessages([msg.key]);
        }
      } catch (err) {
        console.error("Auto status view error:", err.message);
      }
    }
  });
}

module.exports = { startAutoStatusView };
