/**
 * Generic social-media video downloader using yt-dlp.
 * Works with most sites yt-dlp supports: YouTube, Instagram, TikTok, Facebook,
 * Twitter/X, Pinterest, etc. (subject to each site's own restrictions/changes).
 *
 * Reminder: only download content you have the right to download/share.
 * Respect copyright and each platform's terms of service.
 */

const ytdlp = require("yt-dlp-exec");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const config = require("../config");

async function handleDownloadCommand(sock, msg, link) {
  const from = msg.key.remoteJid;

  let statusMsg;
  try {
    statusMsg = await sock.sendMessage(from, { text: "⏳ Downloading..." }, { quoted: msg });

    const id = crypto.randomBytes(4).toString("hex");
    const outTemplate = path.join(config.downloadDir, `${id}.%(ext)s`);

    await ytdlp(link, {
      output: outTemplate,
      format: "mp4/bestvideo+bestaudio/best",
      noPlaylist: true,
      maxFilesize: "100M", // keep under WhatsApp's practical size limits
    });

    const files = fs.readdirSync(config.downloadDir).filter((f) => f.startsWith(id));
    if (!files.length) throw new Error("Download produced no file (link may be unsupported or private).");

    const filePath = path.join(config.downloadDir, files[0]);
    const stat = fs.statSync(filePath);

    if (stat.size > 95 * 1024 * 1024) {
      await sock.sendMessage(from, { text: "⚠️ File is too large to send over WhatsApp (>95MB)." }, { quoted: msg });
    } else {
      await sock.sendMessage(
        from,
        {
          video: fs.readFileSync(filePath),
          caption: `✅ Downloaded via ${config.botName}`,
        },
        { quoted: msg }
      );
    }

    fs.unlinkSync(filePath);
  } catch (err) {
    console.error("Download error:", err.message);
    await sock.sendMessage(
      from,
      { text: `❌ Couldn't download that link.\nReason: ${err.message}` },
      { quoted: msg }
    );
  }
}

module.exports = { handleDownloadCommand };
