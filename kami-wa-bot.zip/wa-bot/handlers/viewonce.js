/**
 * View-once saver — scoped to DIRECT chats with the bot's own number.
 *
 * The bot runs on the owner's own WhatsApp account, so when someone sends a
 * view-once photo/video straight to that number, the owner is the intended
 * recipient and is entitled to keep their own copy of it (same as any other
 * media sent to them directly).
 *
 * It deliberately does NOT act on view-once media in GROUP chats — in a
 * group, a view-once message is addressed to everyone in the group, not
 * specifically to the bot's account, and auto-saving it there would mean
 * quietly capturing something other members expected to disappear after one
 * view. That line stays in place.
 */

const config = require("../config");
const { jidToNumber } = require("./util");

function isGroupChat(jid = "") {
  return jid.endsWith("@g.us");
}

function extractViewOnce(message) {
  // View-once media can arrive as viewOnceMessage, viewOnceMessageV2, or
  // with .viewOnce = true directly on image/video message (newer clients).
  const m =
    message?.viewOnceMessage?.message ||
    message?.viewOnceMessageV2?.message ||
    message?.viewOnceMessageV2Extension?.message ||
    null;

  if (m) return m;

  if (message?.imageMessage?.viewOnce) return { imageMessage: message.imageMessage };
  if (message?.videoMessage?.viewOnce) return { videoMessage: message.videoMessage };

  return null;
}

async function handleViewOnce(sock, msg, { from, senderJid, senderNumber }) {
  // Only direct (1:1) chats with the bot's own number — never groups.
  if (isGroupChat(from)) return false;

  const voContent = extractViewOnce(msg.message);
  if (!voContent) return false;

  try {
    const { downloadMediaMessage } = require("@whiskeysockets/baileys");
    const buffer = await downloadMediaMessage(
      { message: voContent, key: msg.key },
      "buffer",
      {},
      { logger: require("pino")({ level: "silent" }) }
    );

    const isVideo = !!voContent.videoMessage;
    const isOwnMessage = msg.key.fromMe;

    // Save a copy in the same chat.
    await sock.sendMessage(from, {
      [isVideo ? "video" : "image"]: buffer,
      caption: isOwnMessage
        ? "🔓 Saved your own view-once media."
        : `🔓 Saved view-once media from ${senderNumber}.`,
    });

    // If someone else sent it, also forward a copy to the owner so it's kept
    // even if that chat gets cleared — still only ever using the bot's own
    // session, visibly, not a covert message from a third party's number.
    if (!isOwnMessage && senderNumber !== config.ownerNumber) {
      const ownerJid = `${config.ownerNumber}@s.whatsapp.net`;
      await sock.sendMessage(ownerJid, {
        [isVideo ? "video" : "image"]: buffer,
        caption: `🔓 View-once from ${senderNumber} (saved copy).`,
      });
    }

    return true;
  } catch (err) {
    console.error("View-once save error:", err.message);
    return false;
  }
}

module.exports = { handleViewOnce };
