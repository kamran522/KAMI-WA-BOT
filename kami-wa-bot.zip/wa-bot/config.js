// ===== Bot configuration =====
// Edit these values before starting the bot.

module.exports = {
  // Shown in the bot's startup / credit messages.
  ownerName: "Kamran Hasil",

  // Owner's WhatsApp number (also treated as an admin).
  // Format: country code + number, no +, no spaces, no leading 0.
  ownerNumber: "923111008401",

  // Additional admin numbers (owner is automatically included).
  // Admins can use admin-only commands like .viewonce on/off, .autostatus on/off.
  adminNumbers: [
    "923111008401",
  ],

  // Bot display name used in replies / captions.
  botName: "KAMI-WA-BOT",

  // Command prefix.
  prefix: ".",

  // ---- Feature toggles (can also be changed at runtime by admins) ----
  features: {
    videoDownloader: true,   // download videos from a pasted link
    viewOnceSaver: true,     // re-save view-once media sent to the OWNER'S OWN chat only
    autoStatusView: true,    // automatically view contacts' status updates
    startupPing: true,       // send the owner a WhatsApp message when the bot (re)starts
  },

  // Folder where downloaded media is temporarily stored before sending.
  downloadDir: "./downloads",
};
