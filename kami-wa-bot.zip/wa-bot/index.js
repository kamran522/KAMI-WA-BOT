/**
 * KAMI-WA-BOT
 * A Baileys-based WhatsApp bot: video downloader, view-once saver (owner-chat only),
 * and auto status viewer.
 *
 * NOTE ON PRIVACY / HONESTY:
 * - The "startup ping" below only ever uses the BOT'S OWN WhatsApp session to message
 *   the owner. It never sends anything from a third party's number without their
 *   knowledge, and it never sends anything covertly from someone else's account.
 * - The view-once saver only re-saves view-once media sent in the OWNER'S own chat
 *   (messages sent to/by the owner's number), not media observed in group chats or
 *   other people's conversations without their knowledge.
 */

const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  downloadMediaMessage,
} = require("@whiskeysockets/baileys");
const pino = require("pino");
const fs = require("fs");
const path = require("path");
const qrcode = require("qrcode-terminal");

const config = require("./config");
const { handleDownloadCommand } = require("./handlers/downloader");
const { handleViewOnce } = require("./handlers/viewonce");
const { startAutoStatusView } = require("./handlers/statusview");
const { isAdmin, jidToNumber } = require("./handlers/util");

const logger = pino({ level: "silent" }); // set to "info" while debugging

if (!fs.existsSync(config.downloadDir)) fs.mkdirSync(config.downloadDir, { recursive: true });
if (!fs.existsSync("./session")) fs.mkdirSync("./session", { recursive: true });

async function startBot() {
  const { state, saveCreds } = await useMultiFileAuthState("./session");
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    version,
    logger,
    printQRInTerminal: false, // we handle QR manually below
    auth: state,
    browser: ["KAMI-WA-BOT", "Chrome", "1.0.0"],
    generateHighQualityLinkPreview: true,
  });

  // ---- Connection lifecycle ----
  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect, qr } = update;

    if (qr) {
      console.log("\nScan this QR code with WhatsApp (Linked Devices):\n");
      qrcode.generate(qr, { small: true });
    }

    if (connection === "close") {
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      const shouldReconnect = statusCode !== DisconnectReason.loggedOut;
      console.log("Connection closed.", statusCode, "Reconnecting:", shouldReconnect);
      if (shouldReconnect) startBot();
      else console.log("Logged out. Delete ./session and restart to re-link.");
    } else if (connection === "open") {
      console.log(`${config.botName} connected.`);

      if (config.features.startupPing) {
        await sendStartupPing(sock);
      }

      if (config.features.autoStatusView) {
        startAutoStatusView(sock);
      }
    }
  });

  sock.ev.on("creds.update", saveCreds);

  // ---- Incoming messages ----
  sock.ev.on("messages.upsert", async ({ messages, type }) => {
    if (type !== "notify") return;

    for (const msg of messages) {
      try {
        await onMessage(sock, msg);
      } catch (err) {
        console.error("Error handling message:", err);
      }
    }
  });

  return sock;
}

/**
 * Sends a one-time "bot started" notice to the owner, FROM THE BOT'S OWN SESSION.
 * This is disclosed/visible behavior (it's right here in the code and it shows up
 * as a normal WhatsApp message to the owner) — not a covert message sent from
 * someone else's number without their knowledge.
 */
async function sendStartupPing(sock) {
  try {
    const ownerJid = `${config.ownerNumber}@s.whatsapp.net`;
    const who = sock?.user?.id ? jidToNumber(sock.user.id) : "unknown";
    await sock.sendMessage(ownerJid, {
      text:
        `✅ ${config.botName} started.\n` +
        `Linked WhatsApp number: ${who}\n` +
        `Owner: ${config.ownerName}\n` +
        `Time: ${new Date().toLocaleString()}`,
    });
  } catch (err) {
    console.error("Could not send startup ping to owner:", err.message);
  }
}

async function onMessage(sock, msg) {
  if (!msg.message) return;
  const from = msg.key.remoteJid;
  const senderJid = msg.key.participant || msg.key.remoteJid;
  const senderNumber = jidToNumber(senderJid);

  // 1) View-once saver — only acts on messages in the OWNER'S own chat (self-chat
  //    or the owner's number talking to the bot), never on other people's chats.
  if (config.features.viewOnceSaver) {
    const handled = await handleViewOnce(sock, msg, { from, senderJid, senderNumber });
    if (handled) return;
  }

  // Extract plain text (handles normal + extended text messages)
  const body =
    msg.message.conversation ||
    msg.message.extendedTextMessage?.text ||
    msg.message.imageMessage?.caption ||
    msg.message.videoMessage?.caption ||
    "";

  if (!body.startsWith(config.prefix)) return;

  const [rawCmd, ...args] = body.slice(config.prefix.length).trim().split(/\s+/);
  const cmd = rawCmd.toLowerCase();

  switch (cmd) {
    case "dl":
    case "download":
    case "video": {
      if (!config.features.videoDownloader) return;
      const link = args[0];
      if (!link) {
        await sock.sendMessage(from, { text: "Send a link: .dl <video url>" }, { quoted: msg });
        return;
      }
      await handleDownloadCommand(sock, msg, link);
      break;
    }

    case "menu":
    case "help": {
      await sock.sendMessage(
        from,
        {
          text:
            `*${config.botName}*\n` +
            `Owner: ${config.ownerName}\n\n` +
            `${config.prefix}dl <link> — download a video from a social media link\n` +
            `${config.prefix}menu — show this menu\n` +
            (isAdmin(senderNumber, config) ? `\n*Admin:*\n${config.prefix}autostatus on|off\n${config.prefix}viewonce on|off\n` : ""),
        },
        { quoted: msg }
      );
      break;
    }

    case "autostatus": {
      if (!isAdmin(senderNumber, config)) return;
      const on = args[0]?.toLowerCase() === "on";
      config.features.autoStatusView = on;
      await sock.sendMessage(from, { text: `Auto status view: ${on ? "ON" : "OFF"}` }, { quoted: msg });
      break;
    }

    case "viewonce": {
      if (!isAdmin(senderNumber, config)) return;
      const on = args[0]?.toLowerCase() === "on";
      config.features.viewOnceSaver = on;
      await sock.sendMessage(from, { text: `View-once saver (owner chat only): ${on ? "ON" : "OFF"}` }, { quoted: msg });
      break;
    }

    default:
      break;
  }
}

startBot().catch((err) => {
  console.error("Fatal error starting bot:", err);
  process.exit(1);
});
